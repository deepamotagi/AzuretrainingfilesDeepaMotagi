# AKS Single-Node Gateway Example

This project deploys:
- Apache (`replicas: 2`)
- NGINX (`replicas: 2`)
- One gateway (NGINX reverse proxy) exposed through `LoadBalancer` public IP with HTTP

No CPU requests/limits are configured, as requested.

External traffic is HTTP-only:
- Apache and NGINX remain internal-only (`ClusterIP`)

## Files
- `k8s/namespace.yaml`
- `k8s/apache.yaml`
- `k8s/nginx.yaml`
- `k8s/gateway.yaml`

## Deploy
```bash
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/apache.yaml
kubectl apply -f k8s/nginx.yaml
kubectl apply -f k8s/gateway.yaml
```

## Verify
```bash
kubectl get pods -n web-gateway
kubectl get svc -n web-gateway
```

Wait for external IP:
```bash
kubectl get svc gateway -n web-gateway -w
```

## Access
- Gateway root: `http://<PUBLIC_IP>/`
- Apache via gateway: `http://<PUBLIC_IP>/apache/`
- NGINX via gateway: `http://<PUBLIC_IP>/nginx/`
- Health check: `http://<PUBLIC_IP>/healthz`

Get public IP:
```bash
kubectl get svc gateway -n web-gateway -o wide
```

The gateway service is `type: LoadBalancer`, so AKS creates and attaches an Azure Public IP automatically.

## End-to-End Scope
- External clients: HTTP
- Gateway to backends (inside cluster): HTTP over private cluster networking

## Optional: Static Public IP in AKS
For production, create a static Public IP in Azure and bind it to the service via annotations and `loadBalancerIP`.
