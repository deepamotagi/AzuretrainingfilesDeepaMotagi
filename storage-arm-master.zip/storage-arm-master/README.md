# ARM: Storage Account

This project deploys one Azure Storage Account.

## Prerequisites
- Azure subscription
- Azure CLI installed

## Setup and deployment
1. Sign in:
   ```powershell
   az login
   ```
2. Select subscription:
   ```powershell
   az account set --subscription "<subscription-id>"
   ```
3. Create or use a resource group:
   ```powershell
   az group create --name rg-arm-storage-demo --location eastus
   ```
4. Update `parameters.json` with a globally unique storage account name.
5. Deploy:
   ```powershell
   az deployment group create --resource-group rg-arm-storage-demo --template-file azuredeploy.json --parameters @parameters.json
   ```

## Cleanup
```powershell
az group delete --name rg-arm-storage-demo --yes --no-wait
```
