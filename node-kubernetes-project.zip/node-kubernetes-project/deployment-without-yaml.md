# Create a Kubernetes Deployment with 3 Replicas (Without YAML)

This guide uses imperative `kubectl` commands only.

## 1. Prerequisites

- A running Kubernetes cluster
- `kubectl` installed and configured

Quick check:

```bash
kubectl get nodes
```

## 2. Create Deployment with 3 Replicas

Create a Deployment named `nginx-deploy` using `nginx:1.27` and set replicas to 3:

```bash
kubectl create deployment nginx-deploy --image=nginx:1.27 --replicas=3
```

## 3. Verify Deployment and Pods

Check Deployment status:

```bash
kubectl get deployment nginx-deploy
```

Check ReplicaSet and Pods created by the Deployment:

```bash
kubectl get rs
kubectl get pods -l app=nginx-deploy
```

## 4. Optional: Scale Replicas Later

If you want to change replica count after creation:

```bash
kubectl scale deployment nginx-deploy --replicas=5
```

## 5. Optional: Expose Deployment as a Service

```bash
kubectl expose deployment nginx-deploy --type=ClusterIP --port=80 --target-port=80
kubectl get svc nginx-deploy
```

## 6. Delete Resources

Delete service and deployment:

```bash
kubectl delete svc nginx-deploy
kubectl delete deployment nginx-deploy
```


