# Create and Manage Kubernetes Pods Without YAML Files

This guide uses `kubectl` imperative commands only (no `.yml` or `.yaml` manifests).

## 1. Prerequisites

- A working Kubernetes cluster
- `kubectl` installed and configured
- Verify access:

```bash
kubectl version --short
kubectl get nodes
```

## 2. Create Pods

Create a basic pod:

```bash
kubectl run nginx-pod --image=nginx:1.27 --restart=Never
```

Create a pod in a specific namespace:

```bash
kubectl run api-pod --image=nginx:1.27 --restart=Never -n dev
```

Create a pod with a custom command:

```bash
kubectl run busybox-pod --image=busybox:1.36 --restart=Never -- sleep 3600
```

Create a pod with environment variables:

```bash
kubectl run app-pod --image=nginx:1.27 --restart=Never --env="APP_ENV=prod" --env="LOG_LEVEL=info"
```

## 3. View and Inspect Pods

List pods:

```bash
kubectl get pods
```

Wide output (node, IP, etc.):

```bash
kubectl get pods -o wide
```

Watch pod status changes:

```bash
kubectl get pods -w
```

Describe a pod (events and details):

```bash
kubectl describe pod nginx-pod
```

## 4. Access Running Pods

Get logs:

```bash
kubectl logs nginx-pod
```

Follow logs in real time:

```bash
kubectl logs -f nginx-pod
```

Open an interactive shell:

```bash
kubectl exec -it nginx-pod -- /bin/sh
```

Port-forward local port 8080 to container port 80:

```bash
kubectl port-forward pod/nginx-pod 8080:80
```

Copy files to/from a pod:

```bash
kubectl cp ./local-file.txt nginx-pod:/tmp/local-file.txt
kubectl cp nginx-pod:/tmp/local-file.txt ./downloaded-file.txt
```

## 5. Manage Pod Metadata

Add or update a label:

```bash
kubectl label pod nginx-pod app=web --overwrite
```

Add or update an annotation:

```bash
kubectl annotate pod nginx-pod owner=platform-team --overwrite
```

Filter pods by label:

```bash
kubectl get pods -l app=web
```

## 6. Update Pod Configuration (Important)

Most pod spec fields are immutable after creation. To change image/command/ports, recreate the pod:

```bash
kubectl delete pod nginx-pod
kubectl run nginx-pod --image=nginx:1.28 --restart=Never
```

## 7. Delete Pods

Delete one pod:

```bash
kubectl delete pod nginx-pod
```

Delete multiple pods:

```bash
kubectl delete pod nginx-pod api-pod app-pod
```

Delete by label:

```bash
kubectl delete pod -l app=web
```

Delete all pods in current namespace:

```bash
kubectl delete pods --all
```

## 8. Quick Troubleshooting

Check pod phase quickly:

```bash
kubectl get pod nginx-pod -o jsonpath='{.status.phase}'
```

See container restart count:

```bash
kubectl get pod nginx-pod -o jsonpath='{.status.containerStatuses[0].restartCount}'
```

See warning events in namespace:

```bash
kubectl get events --sort-by=.metadata.creationTimestamp
```

## 9. Optional: Generate YAML Without Saving Files

If you want to preview what command-generated resources look like, print YAML to terminal only:

```bash
kubectl run sample --image=nginx --restart=Never --dry-run=client -o yaml
```

This still avoids creating and managing manifest files.
