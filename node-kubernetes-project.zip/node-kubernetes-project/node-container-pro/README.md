# node-container-pro

Kubernetes deployment for `vinodhconnects/node-app-website` with:
- 3 replicas
- ConfigMap-based environment variables (10 vars)
- CPU and memory requests/limits
- LoadBalancer service exposure

## Files
- `configmap.yaml`
- `deployment.yaml`
- `service.yaml`

## Deploy
```bash
kubectl apply -f configmap.yaml
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml
```

## Verify
```bash
kubectl get pods -l app=node-app-website
kubectl get svc node-app-loadbalancer
kubectl describe deployment node-app-deployment
```

## Optional single-command apply
```bash
kubectl apply -f .
```

> Note: If your image listens on a port other than `3000`, update `containerPort` in `deployment.yaml` and `targetPort` in `service.yaml`.
