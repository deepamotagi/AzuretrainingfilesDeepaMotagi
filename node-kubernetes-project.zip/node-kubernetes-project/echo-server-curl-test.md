# Create an Echo Server for Pod-to-Pod Curl Tests

This guide uses imperative `kubectl` commands (no YAML files) to:
- Run an echo server in Kubernetes
- Run a temporary curl client pod
- Send curl requests to test pod-to-pod networking

## 1. Create Echo Server Deployment

```bash
kubectl create deployment echo-server --image=ealen/echo-server:latest --replicas=3
```

## 2. Expose Echo Server Inside Cluster

Create a ClusterIP service so other pods can reach it by DNS name:

```bash
kubectl expose deployment echo-server --name=echo-svc --port=80 --target-port=80 --type=ClusterIP
```

## 3. Verify Pods and Service

```bash
kubectl get deployment echo-server
kubectl get pods -l app=echo-server -o wide
kubectl get svc echo-svc
```

## 4. Start a Curl Client Pod

Run a pod that stays alive so you can execute multiple curl commands:

```bash
kubectl run curl-client --image=curlimages/curl:8.12.1 --restart=Never -- sleep 3600
```

Wait until it is Running:

```bash
kubectl get pod curl-client -w
```

## 5. Curl the Echo Service (Recommended)

From inside `curl-client`, call the service DNS name:

```bash
kubectl exec -it curl-client -- curl -s echo-svc
```

More explicit DNS form:

```bash
kubectl exec -it curl-client -- curl -s echo-svc.default.svc.cluster.local
```

Test a custom path/query:

```bash
kubectl exec -it curl-client -- curl -s "http://echo-svc/hello?from=curl-client"
```

## 6. Curl Individual Pod IPs (Direct Pod Reachability)

Get pod IPs:

```bash
kubectl get pods -l app=echo-server -o wide
```

Use one of the pod IPs directly (replace `<POD_IP>`):

```bash
kubectl exec -it curl-client -- curl -s http://<POD_IP>:80
```

## 7. Optional: Run Curl in a Loop

Useful for checking load balancing across replicas:

```bash
kubectl exec -it curl-client -- sh -c "for i in 1 2 3 4 5; do curl -s echo-svc | grep -E 'host|hostname|ip'; echo '---'; done"
```

## 8. Cleanup

```bash
kubectl delete pod curl-client
kubectl delete svc echo-svc
kubectl delete deployment echo-server
```
