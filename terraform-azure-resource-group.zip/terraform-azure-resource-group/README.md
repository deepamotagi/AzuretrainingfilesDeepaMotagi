# Terraform: Azure Resource Group

This subproject creates a single Azure Resource Group using Terraform.

## Files
- `main.tf`: Provider authentication and resource group definition.

## Notes
Azure credentials are intentionally included directly in `main.tf` as requested.

## Run
```powershell
cd terraform/azure-resource-group
terraform init
terraform validate
terraform plan -out tfplan
terraform apply tfplan
```

## Cleanup
```powershell
terraform destroy -auto-approve
```
