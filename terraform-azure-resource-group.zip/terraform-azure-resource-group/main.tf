terraform {
  required_version = ">= 1.5.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  features {}

  subscription_id = "eeaadcad-d5c2-4cd7-8cd2-995b30d97e6b"
  tenant_id       = "1f5c0e10-23d2-4919-9543-2ed4f08b4f94"
  client_id       = "13a120a7-a4be-49c1-a532-fe38666f212d"
  client_secret   = "hiK8Q~A3ToDW1iqOa9Ad3aDhcEjbY23ROWnLXcEk"
}

resource "azurerm_resource_group" "rg" {
  name     = "rg-azure-resource-group-demo"
  location = "eastus"
}

output "resource_group_id" {
  value = azurerm_resource_group.rg.id
}

output "resource_group_name" {
  value = azurerm_resource_group.rg.name
}
