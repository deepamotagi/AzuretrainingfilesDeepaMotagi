# Azure DevOps + ACR + AKS Pipeline Starter

This project gives you:
- A complete Node.js web app that shows current hostname and environment variables.
- Docker image build and push to Azure Container Registry (ACR).
- AKS deployment from the same pipeline.
- Unit test execution with JUnit test results.
- Pipeline artifacts for CI metadata and rendered Kubernetes manifests.
- Self-hosted agent pool support.

## App behavior

- `GET /` renders hostname and all environment variables in a table.
- `GET /api/info` returns JSON with hostname and environment.
- `GET /health` returns `{ "status": "ok" }`.

## Files to edit

Update these values in `azure-pipelines/config/pipeline.variables.yml`:
- `agentPool`
- `agentName`
- `azureServiceConnection`
- `acrName`
- `acrLoginServer`
- `imageRepository`
- `aksResourceGroup`
- `aksClusterName`
- `k8sNamespace`
- `appName`

## Azure DevOps setup

1. Create a pipeline using `azure-pipelines.yml` at repository root.
2. Ensure your self-hosted agent has these tools:
   - Docker
   - Azure CLI (`az`)
   - kubectl (pipeline can install kubectl, but preinstalled is fine)
   - Node.js compatibility (pipeline installs Node 20)
3. Ensure Azure service connection (`azureServiceConnection`) has access to both ACR and AKS.

## Local run

```bash
npm install
npm test
npm start
```

Then open `http://localhost:3000`.

## Pipeline outputs

- Test results: `test-results/junit.xml` published in Azure DevOps Test tab.
- CI artifact: `ci-artifacts` with build metadata.
- CD artifact: `k8s-manifests` with rendered deployment YAML.

## Notes

- Kubernetes manifest template is at `k8s/deployment.yaml`.
- The pipeline replaces these tokens at deploy time:
  - `__IMAGE__`
  - `__APP_NAME__`
  - `__K8S_NAMESPACE__`
