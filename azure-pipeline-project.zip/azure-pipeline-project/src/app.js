const express = require('express');
const os = require('os');

const app = express();

function buildEnvironmentRows(envObject) {
  return Object.keys(envObject)
    .sort((a, b) => a.localeCompare(b))
    .map((key) => `<tr><td>${key}</td><td>${String(envObject[key])}</td></tr>`)
    .join('');
}

app.get('/health', (_req, res) => {
  res.status(200).json({ status: 'ok' });
});

app.get('/api/info', (_req, res) => {
  res.json({
    hostname: os.hostname(),
    environment: process.env
  });
});

app.get('/', (_req, res) => {
  const hostname = os.hostname();
  const envRows = buildEnvironmentRows(process.env);

  res.type('html').send(`<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Host and Environment Info</title>
  <style>
    body { font-family: Segoe UI, Arial, sans-serif; margin: 2rem; background: #f7f9fc; color: #111; }
    h1 { margin-bottom: 0.5rem; }
    .card { background: #fff; border: 1px solid #dbe3ef; border-radius: 10px; padding: 1rem; }
    table { width: 100%; border-collapse: collapse; margin-top: 1rem; background: #fff; }
    th, td { border: 1px solid #dbe3ef; padding: 0.5rem; text-align: left; font-size: 0.9rem; }
    th { background: #eef3fb; position: sticky; top: 0; }
    .table-wrap { max-height: 65vh; overflow: auto; border-radius: 8px; }
    code { background: #eef3fb; padding: 0.1rem 0.3rem; border-radius: 4px; }
  </style>
</head>
<body>
  <h1>Runtime Details</h1>
  <div class="card">
    <p><strong>Hostname:</strong> <code>${hostname}</code></p>
    <p><strong>API:</strong> <code>/api/info</code></p>
  </div>
  <h2>Environment Variables</h2>
  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>Variable</th><th>Value</th></tr>
      </thead>
      <tbody>
        ${envRows}
      </tbody>
    </table>
  </div>
</body>
</html>`);
});

module.exports = app;
