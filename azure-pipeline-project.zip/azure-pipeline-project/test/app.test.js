const request = require('supertest');
const app = require('../src/app');

describe('application endpoints', () => {
  test('GET /health returns ok', async () => {
    const response = await request(app).get('/health');
    expect(response.statusCode).toBe(200);
    expect(response.body.status).toBe('ok');
  });

  test('GET /api/info returns hostname and environment', async () => {
    const response = await request(app).get('/api/info');
    expect(response.statusCode).toBe(200);
    expect(typeof response.body.hostname).toBe('string');
    expect(response.body.environment).toBeDefined();
  });
});
