# Optional when ARM_* environment variables are set
subscription_id = "eeaadcad-d5c2-4cd7-8cd2-995b30d97e6b"
tenant_id       = "1f5c0e10-23d2-4919-9543-2ed4f08b4f94"
client_id       = "13a120a7-a4be-49c1-a532-fe38666f212d"
client_secret   = "hiK8Q~A3ToDW1iqOa9Ad3aDhcEjbY23ROWnLXcEk"


resource_group_name  = "rg-loadbalancer-vinodh"
location             = "eastus"
virtual_network_name = "vnet-vm-ausc-demo"
virtual_network_cidr = "10.10.0.0/16"
subnet_name          = "snet-vm"
subnet_cidr          = "10.10.1.0/24"

vm_name              = "vm-ubuntu24-docker"
vm_size              = "Standard_B2s"
admin_username       = "azureuser"
admin_password       = "Password@12345"