
# Prometheus + Grafana Monitoring Setup

This folder provides a simple step-by-step guide to install Prometheus and Grafana on Kubernetes using the `kube-prometheus-stack` Helm chart.

## What you get

- Prometheus (metrics collection)
- Grafana (dashboards)
- Alertmanager, node-exporter, kube-state-metrics (installed by the same chart)

## Prerequisites

- Running Kubernetes cluster (multi-node or Minikube)
- `kubectl` connected to your cluster
- `helm` installed
- For Minikube only:

```bash
minikube addons enable metrics-server
```

## Step 1: Add Helm repo

```bash
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo update
```

## Step 2: Create monitoring namespace

```bash
kubectl create namespace monitoring --dry-run=client -o yaml | kubectl apply -f -
```

## Step 3: Install Prometheus + Grafana

```bash
helm upgrade --install monitoring prometheus-community/kube-prometheus-stack -n monitoring
```

## Step 4: Wait for pods

```bash
kubectl get pods -n monitoring
```

Wait until pods show `Running`/`Completed` and ready containers.

## Step 5: Check service names

Service names can vary with chart version/release.

```bash
kubectl get svc -n monitoring
kubectl get svc -n monitoring | findstr grafana
kubectl get svc -n monitoring | findstr prometheus
```

Default names are usually:
- `monitoring-grafana`
- `monitoring-kube-prometheus-prometheus`

## Step 6: Access Grafana and Prometheus

### Option A (recommended): Port-forward

Grafana:

```bash
kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80
```

Prometheus:

```bash
kubectl -n monitoring port-forward svc/monitoring-kube-prometheus-prometheus 9090:9090
```

Open in browser:
- Grafana: http://localhost:3000
- Prometheus: http://localhost:9090

### Option B (Minikube service URL)

```bash
minikube service -n monitoring monitoring-grafana --url
minikube service -n monitoring monitoring-kube-prometheus-prometheus --url
```

### Option C (NodePort for bare-metal labs)

```bash
kubectl -n monitoring patch svc monitoring-grafana -p '{"spec":{"type":"NodePort"}}'
kubectl -n monitoring get svc monitoring-grafana -o wide
```

Access:

```text
http://<NODE_IP>:<NODE_PORT>
```

## Step 7: Login to Grafana

Username:

```text
admin
```

Password:

```bash
kubectl get secret -n monitoring monitoring-grafana -o jsonpath="{.data.admin-password}" | base64 --decode
```

## Step 8: Verify monitoring data

```bash
kubectl get pods -n monitoring
kubectl get svc -n monitoring
kubectl top nodes
kubectl top pods -A
```

If `kubectl top` fails, verify `metrics-server` is running.

## Uninstall

```bash
helm uninstall monitoring -n monitoring
kubectl delete namespace monitoring
```
